EditPolygon v136 — Focused vertex editing for complex polygons

Replace:
  public/assets/editpolygon-app.js
  public/assets/editpolygon.css

Use editpolygon-app-v136.js as editpolygon-app.js.

Key changes:
- Complex Polygon/MultiPolygon editing opens on the primary outer boundary.
- Internal rings and unrelated parts no longer show vertex controls by default.
- Choose primary boundary, all outer boundaries, one part, one ring/hole,
  visible rings, or all rings from the vertex toolbar.
- Midpoint controls default to off for complex geometry.
- Dense hole-centre handles are suppressed in focused complex mode.
- Previous/next ring navigation and Zoom-to-scope controls.
- Hole Manager rows include Edit ring.
- Full geometry is retained; only on-screen editing controls are scoped.
